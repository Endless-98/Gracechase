declare const process: {
  env: {
    [key: string]: string | undefined;
  };
};